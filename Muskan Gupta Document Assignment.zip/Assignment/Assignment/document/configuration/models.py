
from django.db import models
from django.db.models import JSONField

class DocumentConfig(models.Model):
    template_name=models.CharField(max_length=255)
    document_functional_name=models.CharField(max_length=255)
    document_identifier=models.CharField(max_length=255)
    json_data=JSONField(default=dict,null=True,blank=True)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now_add=True)
    is_active=models.BooleanField(default=False)
    is_deleted=models.BooleanField(default=False)

    def __str__(self):
        return self.template_name
