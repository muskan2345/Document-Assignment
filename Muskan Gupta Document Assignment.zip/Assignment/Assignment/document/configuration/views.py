from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import DocumentConfig

def document_config_view(request):
    return render(request, 'document_config.html')

@csrf_exempt
def document_config_api(request):
    """
    API endpoint to handle form submissions.
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)

            template_name = data.get('template_name')
            document_functional_name = data.get('document_functional_name')
            document_identifier = data.get('document_identifier')
            sections = data.get('sections', [])
            sections_data = {}
            for index, section in enumerate(sections):
                section_key = f'section_{index + 1}'
                section_data = {
                    'repeat': 'Y' if section.get('repeat', False) else 'N',
                    'tags': section.get('tags', [])
                }
                sections_data[section_key] = section_data

            json_data = {
                'template_name': template_name,
                'document_functional_name': document_functional_name,
                'document_identifier': document_identifier,
                'data': sections_data
            }
            DocumentConfig.objects.create(
                template_name=template_name,
                document_functional_name=document_functional_name,
                document_identifier=document_identifier,
                json_data=json.dumps(json_data)
            )

            return JsonResponse({'message': 'Document configuration has been successfully submitted.'}, status=200)

        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data.'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    else:
        return JsonResponse({'error': 'Only POST requests are allowed.'}, status=405)
