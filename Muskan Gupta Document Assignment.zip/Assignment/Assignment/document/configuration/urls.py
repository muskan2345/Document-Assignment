
from django.urls import path
from . import views

urlpatterns = [
    path('', views.document_config_view, name='document_config'),
    path('api/document-config/', views.document_config_api, name='document_config_api')
]
