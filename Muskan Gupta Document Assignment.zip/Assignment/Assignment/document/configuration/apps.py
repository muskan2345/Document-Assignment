from django.apps import AppConfig


class ConfigurationConfig(AppConfig):
    name = 'configuration'
